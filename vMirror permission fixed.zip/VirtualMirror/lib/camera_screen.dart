import 'dart:async';
import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:gallery_saver/gallery_saver.dart';
import 'package:path_provider/path_provider.dart';
import 'permission_handler.dart';
import 'camera_web_support.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({Key? key}) : super(key: key);

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> with WidgetsBindingObserver {
  CameraController? _controller;
  List<CameraDescription>? _cameras;
  bool _isPermissionGranted = false;
  bool _isFlashOn = false;
  int _currentZoomLevel = 0; // 0 = 1x, 1 = 2x, 2 = 3x
  final List<double> _zoomLevels = [1.0, 2.0, 3.0];
  bool _isCapturing = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkPermissions();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _disposeCamera();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Handle app lifecycle changes
    if (_controller == null || !_controller!.value.isInitialized) {
      return;
    }
    
    if (state == AppLifecycleState.inactive) {
      _disposeCamera();
    } else if (state == AppLifecycleState.resumed) {
      _initializeCamera();
    }
  }

  Future<void> _checkPermissions() async {
    final permissionStatus = await PermissionHelper.checkAndRequestPermissions();
    
    setState(() {
      _isPermissionGranted = permissionStatus;
    });
    
    if (_isPermissionGranted) {
      _initializeCamera();
    }
  }

  void _disposeCamera() {
    if (_controller != null) {
      _controller!.dispose();
      _controller = null;
    }
  }

  Future<void> _initializeCamera() async {
    try {
      // Use web-specific camera initialization if on web platform
      if (kIsWeb) {
        _controller = await CameraWebSupport.initializeWebCamera();
        if (_controller == null) {
          throw Exception('Failed to initialize web camera');
        }
        
        // Set initial zoom (if available on web)
        try {
          await _controller!.setZoomLevel(_zoomLevels[_currentZoomLevel]);
        } catch (zoomError) {
          // Zoom might not be available on web, just log the error
          print('Zoom not available: $zoomError');
        }
        
        if (mounted) {
          setState(() {});
        }
        return;
      }
      
      // Original mobile initialization
      if (_cameras == null) {
        _cameras = await availableCameras();
      }
      
      // Find front camera
      CameraDescription? frontCamera;
      for (var camera in _cameras!) {
        if (camera.lensDirection == CameraLensDirection.front) {
          frontCamera = camera;
          break;
        }
      }
      
      // If no front camera found, use the first camera
      final selectedCamera = frontCamera ?? _cameras!.first;
      
      // Initialize camera controller
      _controller = CameraController(
        selectedCamera,
        ResolutionPreset.max,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );
      
      await _controller!.initialize();
      
      // Set initial zoom
      await _controller!.setZoomLevel(_zoomLevels[_currentZoomLevel]);
      
      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      print('Error initializing camera: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error initializing camera: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _toggleZoom() async {
    if (_controller == null || !_controller!.value.isInitialized) {
      return;
    }
    
    setState(() {
      _currentZoomLevel = (_currentZoomLevel + 1) % _zoomLevels.length;
    });
    
    try {
      await _controller!.setZoomLevel(_zoomLevels[_currentZoomLevel]);
    } catch (e) {
      print('Error setting zoom level: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error setting zoom level: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _toggleFlash() {
    setState(() {
      _isFlashOn = !_isFlashOn;
    });
  }

  Future<void> _capturePhoto() async {
    if (_controller == null || !_controller!.value.isInitialized || _isCapturing) {
      return;
    }
    
    try {
      setState(() {
        _isCapturing = true;
      });
      
      // Briefly show flash if enabled
      bool wasFlashOn = _isFlashOn;
      if (!_isFlashOn) {
        setState(() {
          _isFlashOn = true;
        });
        
        // Wait a short moment for flash effect
        await Future.delayed(const Duration(milliseconds: 200));
      }
      
      // Capture the image
      final XFile photo = await _controller!.takePicture();
      
      // Handle image saving differently depending on platform
      if (kIsWeb) {
        // On web, we can't directly save to gallery, so show a success message
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Photo captured! Web browsers cannot directly save to gallery.'),
              duration: Duration(seconds: 3),
            ),
          );
        }
      } else {
        // On mobile, save to gallery
        try {
          final result = await GallerySaver.saveImage(photo.path);
          
          // Show success indicator
          if (result == true && mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Photo saved to gallery'),
                duration: Duration(seconds: 2),
              ),
            );
          }
        } catch (saveError) {
          print('Error saving photo to gallery: $saveError');
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Failed to save photo to gallery: $saveError'),
                backgroundColor: Colors.red,
              ),
            );
          }
        }
      }
      
      // Restore flash state if it wasn't on before
      if (!wasFlashOn) {
        setState(() {
          _isFlashOn = false;
        });
      }
      
    } catch (e) {
      print('Error capturing photo: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to capture photo: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isCapturing = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_isPermissionGranted) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Camera and storage permissions are required',
                style: TextStyle(color: Colors.white),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _checkPermissions,
                child: const Text('Grant Permissions'),
              ),
            ],
          ),
        ),
      );
    }

    if (_controller == null || !_controller!.value.isInitialized) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Camera Preview
          Transform.scale(
            scale: 1.0,
            child: Center(
              child: AspectRatio(
                aspectRatio: _controller!.value.aspectRatio,
                child: CameraPreview(_controller!),
              ),
            ),
          ),
          
          // Flash Simulation
          if (_isFlashOn)
            Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.white.withOpacity(0.7),
                  width: 25.0,
                ),
              ),
            ),
          
          // Zoom Level Indicator
          Positioned(
            top: 50,
            right: 20,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.6),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Text(
                '${_zoomLevels[_currentZoomLevel].toInt()}x',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
      
      // Bottom Control Buttons
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: 30.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            // Flash Button
            FloatingActionButton(
              onPressed: _toggleFlash,
              backgroundColor: _isFlashOn ? Colors.amber : Colors.white24,
              heroTag: 'flash',
              child: Icon(
                _isFlashOn ? Icons.flash_on : Icons.flash_off,
                color: _isFlashOn ? Colors.black : Colors.white,
              ),
            ),
            
            // Capture Button
            FloatingActionButton(
              onPressed: _capturePhoto,
              backgroundColor: Colors.white,
              heroTag: 'capture',
              child: _isCapturing
                  ? const CircularProgressIndicator(color: Colors.black)
                  : const Icon(Icons.camera, color: Colors.black, size: 36),
            ),
            
            // Zoom Button
            FloatingActionButton(
              onPressed: _toggleZoom,
              backgroundColor: Colors.white24,
              heroTag: 'zoom',
              child: const Icon(Icons.zoom_in, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
