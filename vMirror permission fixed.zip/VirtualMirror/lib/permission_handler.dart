import 'dart:io' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:permission_handler/permission_handler.dart';

class PermissionHelper {
  static Future<bool> checkAndRequestPermissions() async {
    // Web platform handles permissions differently
    if (kIsWeb) {
      // On web, permissions are requested when the camera is accessed
      // We'll just return true and let the browser handle permission requests
      print('Web platform detected, browser will handle permission requests');
      return true;
    }
    
    print('Checking device permissions...');
    
    // Request camera permission first as it's essential
    var cameraStatus = await Permission.camera.status;
    print('Initial camera permission status: $cameraStatus');
    
    if (!cameraStatus.isGranted) {
      cameraStatus = await Permission.camera.request();
      print('After request, camera permission status: $cameraStatus');
      
      if (!cameraStatus.isGranted) {
        print('Camera permission denied');
        return false;
      }
    }

    // Handle storage permissions based on platform
    if (Platform.isAndroid) {
      // Check Android version for proper permission model
      bool isAndroid13OrAbove = await _isAndroid13OrAbove();
      print('Is Android 13 or above: $isAndroid13OrAbove');
      
      if (isAndroid13OrAbove) {
        // Android 13+ uses the Photos permission
        var photosStatus = await Permission.photos.status;
        print('Photos permission status: $photosStatus');
        
        if (!photosStatus.isGranted) {
          photosStatus = await Permission.photos.request();
          print('After request, photos permission status: $photosStatus');
          
          if (!photosStatus.isGranted) {
            print('Photos permission denied');
            return false;
          }
        }
      } else {
        // Older Android versions use storage permission
        var storageStatus = await Permission.storage.status;
        print('Storage permission status: $storageStatus');
        
        if (!storageStatus.isGranted) {
          storageStatus = await Permission.storage.request();
          print('After request, storage permission status: $storageStatus');
          
          if (!storageStatus.isGranted) {
            print('Storage permission denied');
            return false;
          }
        }
      }
    } else if (Platform.isIOS) {
      // iOS needs photo library permission
      var photosStatus = await Permission.photos.status;
      print('iOS photos library status: $photosStatus');
      
      if (!photosStatus.isGranted) {
        photosStatus = await Permission.photos.request();
        print('After request, iOS photos status: $photosStatus');
        
        if (!photosStatus.isGranted) {
          print('iOS photos permission denied');
          return false;
        }
      }
    }

    print('All required permissions granted');
    return true;
  }
  
  // Helper method to check Android version
  static Future<bool> _isAndroid13OrAbove() async {
    if (!Platform.isAndroid) return false;
    
    try {
      // Android 13 is API level 33
      return int.parse(Platform.operatingSystemVersion.split(' ').last) >= 33;
    } catch (e) {
      print('Error detecting Android version: $e');
      // Default to requiring storage permission if we can't determine version
      return false;
    }
  }
}
