import 'dart:async';
import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';

/// Helper class for handling web-specific camera functionality
class CameraWebSupport {
  /// Checks if the current platform is web
  static bool get isWeb => kIsWeb;
  
  /// Special handling for web camera initialization
  static Future<CameraController?> initializeWebCamera() async {
    if (!isWeb) return null;
    
    try {
      // Get available cameras
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        return null;
      }
      
      // Find front camera or use first available
      CameraDescription? frontCamera;
      for (var camera in cameras) {
        if (camera.lensDirection == CameraLensDirection.front) {
          frontCamera = camera;
          break;
        }
      }
      
      // If no front camera found, use first camera
      final selectedCamera = frontCamera ?? cameras.first;
      
      // Create camera controller optimized for web
      final controller = CameraController(
        selectedCamera,
        // Use medium resolution for better web performance
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );
      
      // Initialize the camera
      await controller.initialize();
      return controller;
    } catch (e) {
      print('Error initializing web camera: $e');
      return null;
    }
  }
  
  /// Handle web-specific image capture and return
  static Future<XFile?> takePictureOnWeb(CameraController controller) async {
    if (!isWeb) return null;
    
    try {
      final XFile picture = await controller.takePicture();
      return picture;
    } catch (e) {
      print('Error taking picture on web: $e');
      return null;
    }
  }
}